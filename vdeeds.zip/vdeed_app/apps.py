from django.apps import AppConfig


class vdeedAppConfig(AppConfig):
    name = 'vdeed_app'
