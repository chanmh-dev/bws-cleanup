$(function () {
    $('.marquee').marquee({
        duration: 40000,
        duplicated: false,
        gap: 0, 
        pauseOnHover: true,
        direction: 'up',
    });
});
